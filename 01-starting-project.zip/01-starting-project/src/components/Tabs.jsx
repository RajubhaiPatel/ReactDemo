// we can use Default Prop value like commented code and remove "ButtonsContainer="menu"" from Example.jsx 
// export default function Tabs({children,buttons,ButtonsContainer='menu'})
export default function Tabs({children,buttons,ButtonsContainer}){
    return(
        <>
        <ButtonsContainer>{buttons}</ButtonsContainer>
        {children}
        </>
    )
}
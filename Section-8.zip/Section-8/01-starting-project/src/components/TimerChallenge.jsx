import { useState,useRef } from "react";

export default function TimerChallenge({ title, targetTime }) {

    const timer= useRef();

    const [timerStarted,setTimerStarted]=useState(false);
    const [timerExpired,setTimerExpired]=useState(false);


    function hadleStart() {
        timer.current=setTimeout(() => {
        setTimerExpired(true);
        }, targetTime * 1000);

        setTimerStarted(true);
    }

    function handleStop() {
        clearTimeout(timer.current);
    }

    return <section className="challange">
        <h2>{title}</h2>
        <p className="challenge-time">
            {targetTime} second{targetTime > 1 ? 's' : ''}
        </p>
        <button onClick={timerStarted ? handleStop : hadleStart}>
            {timerStarted ? 'Stop' : 'Start'} Challenge
        </button>
        <p className={timerStarted ? 'active' : undefined}>
            {timerStarted ? 'Time is runnning....' : 'Timer inactive'}
        </p>
    </section>
}